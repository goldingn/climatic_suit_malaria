cohort.simulate <- function(myDD, myovi, myP, Zout, Zoutovi) {
  DLStempindex(myDD, myovi, myP, Zout, Zoutovi)
}
